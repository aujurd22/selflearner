# Summary of changes for run 762769d1-4320-4a5f-b6ba-7569210dc373
I added a parity lemma about natural numbers to `RequestProject/Main.lean` and proved it. The file builds and contains no `sorry`.

```lean
theorem Nat.even_sum_three_consecutive_iff_odd (n : ℕ) :
    Even (n + (n + 1) + (n + 2)) ↔ Odd n
```

In words: the sum of three consecutive natural numbers is even exactly when the first one is odd. The proof first rewrites the sum as \(3(n+1)\). A product is even when one of its factors is even, and 3 is odd, so the sum is even exactly when \(n+1\) is even, which means \(n\) is odd.

I chose a name that, as far as I know, isn't already used in Mathlib, but I didn't search Mathlib to check.