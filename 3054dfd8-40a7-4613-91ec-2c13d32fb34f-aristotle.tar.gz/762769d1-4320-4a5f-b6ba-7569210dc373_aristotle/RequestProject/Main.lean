import Mathlib

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 20000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

set_option pp.fullNames true
set_option pp.structureInstances true
set_option pp.coercions.types true
set_option pp.funBinderTypes true
set_option pp.letVarTypes true
set_option pp.piBinderTypes true

set_option grind.warning false

/-- The sum of three consecutive natural numbers `n + (n + 1) + (n + 2)` is even
exactly when `n` is odd (since the sum equals `3 * (n + 1)`). -/
theorem Nat.even_sum_three_consecutive_iff_odd (n : ℕ) :
    Even (n + (n + 1) + (n + 2)) ↔ Odd n := by
  have h : n + (n + 1) + (n + 2) = 3 * (n + 1) := by ring
  have h3 : ¬ Even 3 := by decide
  rw [h, Nat.even_mul, Nat.even_add_one (n := n), ← Nat.not_even_iff_odd]
  exact or_iff_right h3
